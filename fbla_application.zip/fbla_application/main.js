const {app} = require('electron')
const {BrowserWindow} = require('electron')

app.on('ready', function(){
  var mainWindow = new BrowserWindow({
    width: 1500,
    height: 1000,
    icon: __dirname + '/favicon.ico'
  })
  mainWindow.setMenu(null);
  mainWindow.loadURL('file://' + __dirname + '/index.html');
})
